public interface ISpecialMove
{
	public void execute(DungeonCharacter source, DungeonCharacter target);
}
